﻿using MySql.Data.MySqlClient;
using System;
using System.Text.RegularExpressions;
namespace Biblioteka
{
    class Klient
    {
        public static Connect c = new Connect();
        private static string imie;
        private static string nazwisko;
        public static string login;
        public MySqlCommand command;
        public MySqlDataReader reader;
        Menu menu = new Menu();
        private static string haslo;
          
        public void Logowanie()
        {
            c.polaczenie();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("►►ZALOGUJ SIĘ◄◄");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("Podaj login: ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            login = Console.ReadLine();
            login.ToLower();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.Yellow;
            command = new MySqlCommand("Select login from klienci where login='" + login + "'", c.connection);
            reader = command.ExecuteReader();
            string login2 = "";
            while (reader.Read())
            {
                login2 = reader.GetString(0);
            }
            reader.Close();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("Podaj hasło: ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            haslo = Console.ReadLine();
            haslo.ToLower();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("");
            string haslo2 = "";
            command = new MySqlCommand("Select password from klienci where login='" + login + "'", c.connection);
            reader = command.ExecuteReader();
            while (reader.Read())
            {
                haslo2 = reader.GetString(0);
            }
            reader.Close();
            if ((login == login2 && haslo != haslo2) || (login != login2 && haslo != haslo2) || (login.Length < 3 || haslo.Length < 3)) {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Clear();
                    Console.WriteLine("►Logowanie się nie powiodło, spróbuj zalogować się jeszcze raz.");
                    c.connection.Close();
                    Logowanie();
                }
            else
                {
                    Console.WriteLine("Zalogowano...");
                    menu.Opcje();
                }
        }
        public void Rejestracja()
        {
            c.polaczenie();
            Regex rimie = new Regex("^([a-z]+[,.]?[ ]?|[a-z]+['-]?)+$", RegexOptions.IgnoreCase);
            Regex rnazwisko = new Regex("^([a-z]+[,.]?[ ]?|[a-z]+['-]?)+$", RegexOptions.IgnoreCase);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("►►REJESTRACJA◄◄");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("→Podaj Imie: ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            imie = Console.ReadLine();
            while (!(rimie.IsMatch(imie)) || (imie.Length < 3) || imie.Length > 31 || imie.Equals("null"))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Podaj imie jeszcze raz: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                imie = Console.ReadLine();
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("→Podaj Nazwisko: ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            nazwisko = Console.ReadLine();
            while (!(rnazwisko.IsMatch(nazwisko)) || (nazwisko.Length < 3) || nazwisko.Length > 31 || nazwisko.Equals("null"))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Podaj nazwisko jeszcze raz: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                nazwisko = Console.ReadLine();
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("→Podaj Hasło: ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            haslo = Console.ReadLine();
            while (haslo.Length < 3 || haslo.Length > 16 || haslo.Equals("null"))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Podaj hasło jeszcze raz: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                haslo = Console.ReadLine();
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            char[] logintab = new char[6];
            logintab[0] = imie[0];
            logintab[1] = imie[1];
            logintab[2] = imie[2];
            logintab[3] = nazwisko[0];
            logintab[4] = nazwisko[1];
            logintab[5] = nazwisko[2];
            Random rand = new Random();
            int los = rand.Next(1, 100);
            string login = "";
            for (int i = 0; i < logintab.Length; i++)
            {
                login += logintab[i];
            }
            login += los;
            Console.Write("Twój login: ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(login);
            try
            {
                command = new MySqlCommand("INSERT INTO klienci(imie,nazwisko,login,password) VALUES (" + "'" + imie + "'," + "'" + nazwisko + "'," + "'" + login + "'," + "'" + haslo + "')", c.connection);
                int a = command.ExecuteNonQuery();
                c.connection.Close();
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("Twój login: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write(login);
                c.connection.Close();
                Console.WriteLine("");
                Logowanie();
            }catch(MySqlException)
            {
                Console.Clear();
                c.connection.Close();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Rejestracja nie przebiegła pomyślnie, spróbuj jeszcze raz!");
                Console.WriteLine("");
                Console.ResetColor();
                Rejestracja();
            }
        }
    }
}

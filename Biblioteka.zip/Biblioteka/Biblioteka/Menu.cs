﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteka
{
    class Menu
    {
        public static Connect c = new Connect();
        public void Start()
        {
            Klient klient = new Klient();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("►>►>►>►");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("BIBLIOTEKA");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("◄<◄<◄<◄\n");
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("→ 1.");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(" Logowanie");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("→ 2.");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(" Rejestracja");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("→ 3. ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Wyłącz program");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("");
            Console.Write("» Naciśnij");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(" (1/2/3)");
            Console.ForegroundColor = ConsoleColor.Green;
            switch(Console.ReadKey().Key) {
                case ConsoleKey.D1:
                    Console.Clear();
                    klient.Logowanie();
                    break;
                case ConsoleKey.D2:
                    Console.Clear();
                    klient.Rejestracja();
                    break;
                case ConsoleKey.D3:
                    Console.Clear();
                    c.connection.Close();
                    Environment.Exit(0);
                break;
                default:
                    Console.Clear();
                    Start();
                    break;


            }
        }
        public void Opcje()
        {
            Ksiazka ksiazka = new Ksiazka();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("►▬▬▬WYBIERZ▬▬▬◄");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine();
            Console.Write("→ 1.");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Wypożycz książkę");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("→ 2.");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Oddaj książkę");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("→ 3.");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Wyłącz program");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("");
            Console.Write("» Naciśnij");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" (1/2/3)");
                Console.ForegroundColor = ConsoleColor.Yellow;
                switch(Console.ReadKey().Key)
                {
                    case ConsoleKey.D1:
                        ksiazka.pokazKsiazki();
                        break;
                    case ConsoleKey.D2:
                        ksiazka.oddaj();
                        break;
                case ConsoleKey.D3:
                    Console.Clear();
                    c.connection.Close();
                    Environment.Exit(0);
                    break;
                default:
                        Console.Clear();
                        Opcje();
                        break;
                }
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
    }
}

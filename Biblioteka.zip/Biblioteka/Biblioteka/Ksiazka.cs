﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using MySql.Data.MySqlClient;

namespace Biblioteka
{
    class Ksiazka
    {
        public static Connect c = new Connect();
        public static MySqlCommand command;
        public static MySqlDataReader reader;
        public static int wybor;
        Menu menu = new Menu();
        public void pokazKsiazki()
        {
            Console.Clear();
            c.connection.Close();
            c.polaczenie();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Wybierz rodzaj książki");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("1 - epika, 2 - dramat, 3 - liryka");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("\n");
            Console.Write("→ Naciśnij");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write(" (1/2/3)");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("→ Naciśnij F1 aby wyjść do Menu Opcji");
            switch (Console.ReadKey().Key)
            {
                case ConsoleKey.D1:
                    Console.Clear();
                    command = new MySqlCommand("Select * from ksiazki where typ = 1", c.connection);
                    reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        string tytul = reader.GetString(1);
                        string autor = reader.GetString(2);
                        int ilosc = reader.GetInt32(4);
                        if (ilosc == 0 || ilosc < 0)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine(" #" + id + "  „" + tytul + "”  - " + autor);
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine(" #" + id + "  „" + tytul + "”  - " + autor);
                        }
                    }
                    reader.Close();
                    wypozycz();
                    break;
                case ConsoleKey.D2:
                    Console.Clear();
                    command = new MySqlCommand("Select * from ksiazki where typ = 2", c.connection);
                    reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        string tytul = reader.GetString(1);
                        string autor = reader.GetString(2);
                        int ilosc = reader.GetInt32(4);
                        if (ilosc == 0)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine(" #" + id + "  „" + tytul + "”  - " + autor);
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine(" #" + id + "  „" + tytul + "”  - " + autor);
                        }
                    }
                    reader.Close();
                    wypozycz();
                    break;
                case ConsoleKey.D3:
                    Console.Clear();
                    command = new MySqlCommand("Select * from ksiazki where typ = 3", c.connection);
                    reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        string tytul = reader.GetString(1);
                        string autor = reader.GetString(2);
                        int ilosc = reader.GetInt32(4);
                        if (ilosc == 0)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine(" #" + id + "  „" + tytul + "”  - " + autor);
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine(" #" + id + "  „" + tytul + "”  - " + autor);
                        }
                    }
                    reader.Close();
                    wypozycz();
                    break;
                case ConsoleKey.F1:
                    menu.Opcje();
                    break;
                default:
                    pokazKsiazki();
                    break;

            }
        }
        public void wypozycz()
        {
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("►Wpisz numer książki, którą chcesz wypożyczyć");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("Wybieram → #");
            try
            {
                wybor = Convert.ToInt32(Console.ReadLine());
            }catch(Exception)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("");
                Console.WriteLine("Nie prawidłowy numer książki");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Czy chcesz wypożyczyć coś innego? Y/N");
                if (Console.ReadKey().Key == ConsoleKey.Y)
                {
                    Console.Clear();
                    c.connection.Close();
                    pokazKsiazki();
                    wypozycz();
                }
                else
                {
                    menu.Opcje();
                }
            }
            Console.ForegroundColor = ConsoleColor.Blue;
            command = new MySqlCommand("Select id from klienci where login='" + Klient.login + "'",c.connection);
            command.ExecuteNonQuery();
            reader = command.ExecuteReader();
            int idklienta = 0;
            while (reader.Read())
            {
                idklienta = reader.GetInt32(0);
            }
            reader.Close();
            command = new MySqlCommand("Select * from ksiazki where id=" +wybor, c.connection);
            command.ExecuteNonQuery();
            reader = command.ExecuteReader();
            string nazwa = "";
            int idksiazki = 0;
            while (reader.Read())
            {
                idksiazki = reader.GetInt32(0);
                nazwa = reader.GetString(1);

            }
            reader.Close();
            if (idksiazki > 0 || idksiazki<0)
            {
                command = new MySqlCommand("Select ilosc from ksiazki where id=" + wybor, c.connection);
                command.ExecuteNonQuery();
                reader = command.ExecuteReader();
                int ilosc = 0;
                while (reader.Read())
                {
                    ilosc = reader.GetInt32(0);
                }
                reader.Close();
                if (ilosc == 0 || ilosc < 0)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("");
                    Console.WriteLine("Tej książki obecnie nie mamy na stanie");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Czy chcesz wypożyczyć coś innego? Y/N");
                    if (Console.ReadKey().Key == ConsoleKey.Y)
                    {
                        Console.Clear();
                        c.connection.Close();
                        pokazKsiazki();
                        wypozycz();
                    }
                    else
                    {
                        menu.Opcje();
                    }
                }
                else
                {
                    command = new MySqlCommand("Select id_ksiazki from wypozyczenia where id_klienci=" + idklienta + " and id_ksiazki=" + wybor, c.connection);
                    command.ExecuteNonQuery();
                    reader = command.ExecuteReader();
                    int idksiazki2 = 0;
                    while (reader.Read())
                    {
                        idksiazki2 = reader.GetInt32(0);
                    }
                    reader.Close();
                    if (idksiazki != idksiazki2)
                    {
                        command = new MySqlCommand("INSERT INTO wypozyczenia(id_klienci,id_ksiazki,tytul) VALUES(" + idklienta + "," + idksiazki + ",'" + nazwa + "')", c.connection);
                        command.ExecuteNonQuery();
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("");
                        Console.Write("→ Wypożyczyłeś: ");
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.Write(nazwa);
                        command = new MySqlCommand("update ksiazki set ilosc = ilosc-1 where id=" + idksiazki,c.connection);
                        command.ExecuteNonQuery();
                        Console.WriteLine("");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Czy chcesz coś jeszcze wypożyczyć?");
                        Console.WriteLine("Wciśnij Y/N");
                        if(Console.ReadKey().Key==ConsoleKey.Y)
                        {
                            Console.Clear();
                            c.connection.Close();
                            pokazKsiazki();
                            wypozycz();
                        }
                        else
                        {

                            menu.Opcje();
                        }
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("›Już wypożyczyłeś tę książkę");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Czy chcesz wypożyczyć coś innego");
                        Console.WriteLine("Wciśnij Y/N");
                        if (Console.ReadKey().Key == ConsoleKey.Y)
                        {
                            Console.Clear();
                            c.connection.Close();
                            pokazKsiazki();
                            wypozycz();
                        }
                        else
                        {
                            menu.Opcje();
                        }
                    }
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("");
                Console.WriteLine("Nie prawidłowy numer książki");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Czy chcesz wypożyczyć coś innego? Y/N");
                if (Console.ReadKey().Key == ConsoleKey.Y)
                {
                    Console.Clear();
                    c.connection.Close();
                    pokazKsiazki();
                    wypozycz();
                }
                else
                {
                    menu.Opcje();
                }
            }
        }
        public void oddaj()
        {
            Console.Clear();
            c.connection.Close();
            c.polaczenie();
            command = new MySqlCommand("Select id from klienci where login='" + Klient.login + "'", c.connection);
            command.ExecuteNonQuery();
            reader = command.ExecuteReader();
            int idklienta = 0;
            while (reader.Read())
            {
                idklienta = reader.GetInt32(0);
            }
            reader.Close();
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("»Lista książek wypożyczonych:");
            Console.WriteLine("");
            command = new MySqlCommand("select id_ksiazki,tytul from wypozyczenia where id_klienci=" + idklienta, c.connection);
            command.ExecuteNonQuery();
            reader = command.ExecuteReader();
            int idksiazki = 0;
            string tytul = "";
            while (reader.Read())
            {
                idksiazki = reader.GetInt32(0);
                tytul = reader.GetString(1);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write(" #" + idksiazki);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(" " + tytul);
            }
            reader.Close();
            if (idksiazki == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Brak książek do oddania");
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("Kliknij dowolny przycisk na klawiaturze\naby przejść do menu opcji");
                if (Console.ReadKey().Key == ConsoleKey.Escape)
                {
                    menu.Opcje();
                }
                else
                {
                    menu.Opcje();
                }
            }
            else
            {
                Console.WriteLine("");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("Wybieram → #");
                try
                {
                    wybor = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("");
                    Console.WriteLine("Nie prawidłowy numer książki");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Czy chcesz oddać coś innego? Y/N");
                    if (Console.ReadKey().Key == ConsoleKey.Y)
                    {
                        Console.Clear();
                        c.connection.Close();
                        oddaj();
                    }
                    else
                    {
                        menu.Opcje();
                    }
                }
                command = new MySqlCommand("select id_klienci,tytul from wypozyczenia where id_ksiazki=" + wybor, c.connection);
                command.ExecuteNonQuery();
                reader = command.ExecuteReader();
                idklienta = 0;
                while (reader.Read())
                {
                    idklienta = reader.GetInt32(0);
                    tytul = reader.GetString(1);
                }
                reader.Close();
                command = new MySqlCommand("Select id from klienci where login='" + Klient.login + "'", c.connection);
                command.ExecuteNonQuery();
                reader = command.ExecuteReader();
                int klientid = 0;
                while (reader.Read())
                {
                    klientid = reader.GetInt32(0);
                }
                if (klientid != idklienta)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("");
                    Console.WriteLine("»Nie poprawny numer książki");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Czy chcesz oddać coś innego? Y/N");
                    if (Console.ReadKey().Key == ConsoleKey.Y)
                    {
                        Console.Clear();
                        c.connection.Close();
                        oddaj();
                    }
                    else
                    {
                        menu.Opcje();
                    }
                }
                else
                {
                    if (idklienta == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("");
                        Console.WriteLine("»Nie poprawny numer książki");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Czy chcesz oddać coś innego? Y/N");
                        if (Console.ReadKey().Key == ConsoleKey.Y)
                        {
                            Console.Clear();
                            c.connection.Close();
                            oddaj();
                        }
                        else
                        {
                            menu.Opcje();
                        }
                    }
                    else
                    {
                        reader.Close();
                        command = new MySqlCommand("delete from wypozyczenia where id_klienci=" + idklienta + " and id_ksiazki=" + wybor, c.connection);
                        command.ExecuteNonQuery();
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("");
                        Console.Write("»Oddałeś: ");
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.Write(tytul);
                        command = new MySqlCommand("update ksiazki set ilosc = ilosc+1 where id=" + wybor, c.connection);
                        command.ExecuteNonQuery();
                        Console.WriteLine("");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Czy chcesz coś jeszcze oddać? Y/N");
                        if (Console.ReadKey().Key == ConsoleKey.Y)
                        {
                            oddaj();
                        }
                        else
                        {
                            menu.Opcje();
                        }
                    }
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;

namespace Biblioteka
{
    class Connect
    {
        public MySqlConnection connection;
        public Connect()
        {
            connection = new MySqlConnection("datasource = localhost; username = root; password =; database = biblioteka");
        }
        public void polaczenie()
        {
            try
            {
                connection.Open();
                Console.ForegroundColor = ConsoleColor.White;
            }
            catch(Exception)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Błąd połączenia z bazą danych\n");
                Console.ResetColor();
                Environment.Exit(0);
            }
        }
    }
}
